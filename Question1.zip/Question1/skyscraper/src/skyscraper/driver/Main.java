package skyscraper.driver;

import java.util.Scanner;

import skyscraper.construction.Floor;

public class Main {
	
	static Floor floor= new Floor();
	public static int[] arr;
	static Scanner s;
	static int amount;
	static int num;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("enter the total no of floors in the building");
		s = new Scanner(System.in);
		num = s.nextInt();
			arr = new int[num];
			for (int i=0; i<num; i++) {
				System.out.println("enter the floor size given on day : "+(i+1));
				arr[i]=s.nextInt();
			};
		floor.orderofconst(args);

	}
	

}
