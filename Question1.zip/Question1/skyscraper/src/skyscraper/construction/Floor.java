package skyscraper.construction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import skyscraper.driver.Main;

public class Floor {
	
	static Main main= new Main();
	public static int[] arr;
	public static int[] temp;
	public static int[] temp1;
	public static int[] temp2;


	public static void orderofconst(String[] args) {
		arr=main.arr;
		temp = new int[arr.length];
		temp1 = new int[temp.length];
		temp2 = new int[arr.length-temp.length];
		List temp = new ArrayList();
		List temp1 = new ArrayList();
		List temp2 = new ArrayList();

		int val = 0;
		val=Arrays.stream(arr).max().getAsInt();

		for (int i = 0; i < arr.length; i++) { 
			if(arr[i] >= val) {
				val=val-1;
		        boolean ans = temp.contains(val);
				if(ans) {
					val=val-1;
			        boolean ans1 = temp.contains(val);
					if(ans1) {
						constructed_pend.add(arr[i]); 
						System.out.println("Day"+ (i+1)+" : ");
						List<String> newList2 = new ArrayList<String>(constructed_pend);
						newList2.addAll(temp);
						Collections.sort(newList2,Collections.reverseOrder());
						System.out.println(newList2);

					}
					else {
						constructed_pend.add(arr[i]); 
						System.out.println("Day"+ (i+1)+" : ");
						List<String> newList1 = new ArrayList<String>(constructed_pend);
						newList1.addAll(temp);
						Collections.sort(newList1,Collections.reverseOrder());
						System.out.println(newList1);	
					}
				}
				else {
					temp2.add(arr[i]); 
					System.out.println("Day"+ (i+1)+" : ");	
				}
			}
			else {
				temp.add(arr[i]);
				System.out.println("Day"+ (i+1)+" : ");
				}
		}
		if(temp2.isEmpty()) {
			List<String> newList2 = new ArrayList<String>(constructed_pend);
			newList2.addAll(temp);
			Collections.sort(newList2,Collections.reverseOrder());
			System.out.println(newList2);
		}
		else {
			System.out.println(temp2);
		}
	}
}
